// Importando as dependencias do ReactJS e ReactNative
import React, { Component } from "react";
import { View, Text, Button, TouchableOpacity } from "react-native"; 
import { NavigationProp } from "@react-navigation/native";
// Crie um arquivo na pasta 'assets/styles' o arquivo 'styles_aula03.ts'
import styles from "../assets/styles/styles_aula03";
/*
    Definição da interface Props, que descereve as propiedades que calsses HomeScreen irá receber
    A propiedade navigation é do tipo 'NavigationProp' e é usada para navegar entre telas de aplicação
*/ 
interface Props{
    // A navegação é tipada com qualquer tipo de parâmetro (poder ser ajustado conforme a necessidade)
    navigation: NavigationProp<any>; 
}
// Classe 'HomeScreen' é uma tela do aplicativo, estende Component e recebe Props como tipo para as propiedades
class HomeScreen extends Component<Props>{
    render(){
        return(
            // A View é o container da tela, com estilos aplicados
            <View style={styles.container}>
                {/* Componente Text exibe o titúlo na telas */}
                <Text style={styles.title}>Bem Vindo ao APP - Senac TITO -</Text>

                {/* Botão tradicionaldo React Native, quando for pressionado navega para a tela 'Details' */}
                <Button
                    title="Ir para os Detalhes!!!"
                    // Navega para a tela de Detalhes 'Details'
                    onPress={() => this.props.navigation.navigate('Details')}
                />
                {/* Componente TouchhableOpacity é mais flexivel, usado para deinir área clicavel 
                Aqui, ele támbem navega para a tela 'Details', e tem um comportamento de Botão 
                */}

                <TouchableOpacity
                //Aplica um estilo para o botão 
                style={styles.button}
                // Navegação para a tela de Detalhes 'Details'
                onPress={() => this.props.navigation.navigate('Details')}
                >
                    {/* Texto dentro do TochableOpacity, com estilos de formatação do texto do botão */}
                    <Text style={styles.buttonText}>Ir para os detalhes!</Text>
                 </TouchableOpacity>   
            </View> 
        );
    }
}

/*
    Exporta o componente HomeScreen como padrão deste arquivo
    Isso permite que o componente seja importado sem a necessidade de chaves em outros arquivos
*/
export default HomeScreen;