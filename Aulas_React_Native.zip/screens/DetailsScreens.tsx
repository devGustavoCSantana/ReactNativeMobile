/*
    Importação dos modulos necessarios do React e React Native
    React é necessario para criar componentes React
    View e Text são componentes de React Native para exibir o conteudo na tela

*/
import React, { Component } from "react";
import { View, Text } from "react-native";
// importando do arquivo de estilos 
import styles from "../assets/styles/styles_aula03"; 
/*
    Definiçõa da Class 'DetailsScreen', que é um componente de classe que herda do component 
    Permitindo que ele tenha recursos do React
*/
class DetailsScreen extends Component{
    render(){
        return(
            /*
                View é um container que envolve outros elementos na tela
                Estilos é aplicado à View a partir do arquivo de estilos
            */
           <View style={styles.container}>
            {/* Componente Text exibe o titulo na tela com estilos aplicados */}
            <Text style={styles.title}>DETALHES!</Text>
            {/* Texto da pagina de detalhes  */}
                <Text style={styles.text}>
                    Lorem, ipsum dolor sit amet consectetur 
                    adipisicing elit. Incidunt, obcaecati? 
                    Reprehenderit enim impedit 
                    architecto, eaque, quaerat sapiente 
                    dolore deserunt sint a iusto fuga, 
                    minus optio dolor praesentium eveniet! 
                    Dolor, rerum.
                </Text>
           </View>
        );
    }
}
/*
    Exporta o componente HomeScreen como padrão deste arquivo
    Isso permite que o componente seja importado sem a necessidade de chaves em outros arquivos
*/
export default DetailsScreen;