import React, { Component } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

class App extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Cabeçalho</Text>
        </View>
        <View style={styles.main}>
          <Text style={styles.mainText}>Corpo</Text>
        </View>
        <View style={styles.footer}>
          <Text style={styles.footerText}>Rodapé</Text>
        </View>
      </View>
    );
  }
}

// Construção de CSS
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    backgroundColor: '#f000',
  },
  header: {
    backgroundColor: '#4caf50',
    padding: 20,
    width: 150,
    height: 150,
    marginLeft: 130,
    paddingTop: 60,
    alignItems: 'center',
  },
  main: {
    backgroundColor: '#FFD700',
    padding: 20,
    width: 300,
    height: 150,
    marginLeft: 50,
    alignItems: 'center',
  },
  footer: {
    backgroundColor: '#00FF00',
    padding: 20,
    width: 150,
    height: 100,
    marginLeft: 130,
    alignItems: 'center',
  },
  // Estilos para os textos
  headerText: {
    fontSize: 24,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  mainText: {
    fontSize: 20,
    color: '#000000',
  },
  footerText: {
    fontSize: 18,
    color: '#FFFFFF',
    fontStyle: 'italic',
  },
});

export default App;
